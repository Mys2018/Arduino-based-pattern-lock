/*
  Graphic lock on Arduino Mega 2560: FSM + EEPROM + servo

  Wiring:
    Joystick KY-023 : VRx -> A0, VRy -> A1, SW -> D12
    Buzzer          : D8
    Red LED         : D6 (via 220 ohm)
    Green LED       : D7 (via 220 ohm)
    Servo SG90      : SIG -> D9
    LCD 1602 (I2C)  : SDA -> D20, SCL -> D21
    8x8 matrix      : MAX7219 module: DIN -> D51, CS -> D53, CLK -> D52,
                      VCC -> 5V, GND -> GND

  Matrix cells 0..63 (left to right, top to bottom):
       0  1  2 ...  7
       8  9 10 ... 15
      ...
      56 57 58 ... 63

  CONTROLS
    Choosing the start LED (Serial Monitor, 9600 baud):
        w/a/s/d - up/left/down/right, e - confirm,
        r       - erase the password and set a new one
    Entering the password (path of LIMIT LEDs), starting from the chosen LED:
        joystick - one deflection = one step, return to center to step again
        or w/a/s/d in the Serial Monitor - the same steps
        joystick button (SW) or e in the Serial Monitor - Enter

  WRONG PASSWORD
    1st mistake: slow beeps
    2nd mistake: fast beeps
    3rd mistake: BLOCKED is shown on the LCD, locked for BLOCK_MS

  PASSWORD
    - if EEPROM has no password, the first entered path is saved as the password;
    - after that the entered path is compared with the one stored in EEPROM.

  Libraries: LiquidCrystal I2C (Frank de Brabander), LedControl.
*/

#include <Servo.h>
#include <EEPROM.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <LedControl.h>

// ---------- Settings ----------
const uint8_t  MATRIX_SIDE  = 8;
const uint8_t  CELLS        = MATRIX_SIDE * MATRIX_SIDE;
const uint8_t  LIMIT        = 4;                  // password length
const uint8_t  MAX_ATTEMPTS = 3;
const uint16_t START_MS     = 1500;               // startup blinking
const uint32_t BLOCK_MS     = 10000;              // lockout timer

// Pins
const uint8_t MATRIX_DIN    = 51;
const uint8_t MATRIX_CLK    = 52;
const uint8_t MATRIX_CS     = 53;
const uint8_t JOY_X         = A0;
const uint8_t JOY_Y         = A1;
const uint8_t JOY_SW        = 12;
const uint8_t BUZZER_PIN    = 8;
const uint8_t LED_RED       = 6;
const uint8_t LED_GREEN     = 7;
const uint8_t SERVO_PIN     = 9;

LedControl matrix(MATRIX_DIN, MATRIX_CLK, MATRIX_CS, 1);   // one MAX7219 module

// Joystick
const int  JOY_CENTER      = 512;
const int  JOY_TRIGGER     = 300;                 // deflection that triggers a step
const int  JOY_RELEASE     = 150;                 // "centered" zone, re-arms the stick
const bool JOY_INVERT_X    = true;                // Wokwi: right = 0, left = 1023 (use false for a real KY-023 if needed)
const bool JOY_INVERT_Y    = true;                // Wokwi: up = 1023, down = 0 (use false for a real KY-023 if needed)

// LCD
const uint8_t LCD_ADDR = 0x27;                    // if the screen is blank try 0x3F
LiquidCrystal_I2C lcd(LCD_ADDR, 16, 2);

// Servo
const uint8_t  ANGLE_CLOSED     = 0;
const uint8_t  ANGLE_OPEN       = 90;
const uint16_t STEP_INTERVAL_MS = 15;             // 1 degree per 15 ms
const uint32_t HOLD_MS          = 5000;           // stay open for 5 s

// EEPROM: [0] = marker, [1..LIMIT] = path
const uint8_t  EE_MAGIC = 0xA5;

// ---------- FSM states ----------
enum State { START, CHOOSE_START, INPUT_PATH, CHECK_PASS, UNLOCKED, BLOCKED };
State state = START;

void onEnter(State s);

const char* stateName(State s) {
  switch (s) {
    case START:        return "START";
    case CHOOSE_START: return "CHOOSE_START";
    case INPUT_PATH:   return "INPUT_PATH";
    case CHECK_PASS:   return "CHECK_PASS";
    case UNLOCKED:     return "UNLOCKED";
    case BLOCKED:      return "BLOCKED";
  }
  return "?";
}

// ---------- Flowchart variables ----------
uint8_t  attemptCount = 0;
int8_t   currentLED   = -1;
int8_t   path[LIMIT];
uint8_t  pathLength   = 0;
uint32_t stateEntered = 0;
bool     recordMode   = false;   // true: no password in EEPROM, record a new one

// Indication
bool     greenOn      = false;   // green LED: lock is open
uint32_t redUntil     = 0;       // red LED stays on until this moment
uint8_t  lastSecLeft  = 255;

// ---------- LCD ----------
void lcdLine(uint8_t row, const __FlashStringHelper* text) {
  lcd.setCursor(0, row);
  const char* p = (const char*)text;
  uint8_t n = 0;
  char c;
  while (n < 16 && (c = pgm_read_byte(p++)) != 0) {
    lcd.print(c);
    n++;
  }
  while (n++ < 16) lcd.print(' ');
}

void lcdProgress() {
  lcd.setCursor(0, 1);
  lcd.print(F("Len "));
  lcd.print(pathLength);
  lcd.print('/');
  lcd.print(LIMIT);
  lcd.print(F(" SW/e=OK  "));
}

// ---------- Buzzer ----------
void beepMove()    { tone(BUZZER_PIN, 2000, 30); }
void beepOk()      { tone(BUZZER_PIN, 1500, 250); }
void beepError()   { tone(BUZZER_PIN, 300, 400); }

// Series of beeps without delay: count, pause between beeps (ms)
uint8_t  beepsLeft    = 0;
uint16_t beepInterval = 0;
uint32_t nextBeepAt   = 0;

void startBeeps(uint8_t count, uint16_t intervalMs) {
  beepsLeft    = count;
  beepInterval = intervalMs;
  nextBeepAt   = millis();
}

void beeperUpdate() {
  if (beepsLeft > 0 && millis() >= nextBeepAt) {
    tone(BUZZER_PIN, 1000, 80);
    beepsLeft--;
    nextBeepAt = millis() + beepInterval;
  }
}

// ---------- Servo (no delay) ----------
Servo lockServo;
enum LockState { LOCK_CLOSED, LOCK_OPENING, LOCK_OPEN_HOLD, LOCK_CLOSING };
LockState lockState = LOCK_CLOSED;
int      currentAngle  = ANGLE_CLOSED;
int      targetAngle   = ANGLE_CLOSED;
uint32_t lastStepTime  = 0;
uint32_t holdStartTime = 0;

void lockOpen() {
  if (lockState == LOCK_OPENING || lockState == LOCK_OPEN_HOLD) return;
  targetAngle = ANGLE_OPEN;
  lockState = LOCK_OPENING;
  Serial.println(F("  [SERVO] Opening..."));
}

void lockClose() {
  if (lockState == LOCK_CLOSING || lockState == LOCK_CLOSED) return;
  targetAngle = ANGLE_CLOSED;
  lockState = LOCK_CLOSING;
  Serial.println(F("  [SERVO] Closing..."));
}

// Lock is closed again: green LED goes off
void onLockClosed() {
  greenOn = false;
  Serial.println(F("  [SERVO] Closed, green LED OFF"));
}

void lockUpdate() {
  uint32_t now = millis();

  if (lockState == LOCK_OPENING || lockState == LOCK_CLOSING) {
    if (now - lastStepTime >= STEP_INTERVAL_MS) {
      lastStepTime = now;
      currentAngle += (targetAngle > currentAngle) ? 1 : -1;
      lockServo.write(currentAngle);

      if (currentAngle == targetAngle) {
        if (lockState == LOCK_OPENING) {
          lockState = LOCK_OPEN_HOLD;
          holdStartTime = now;
          Serial.println(F("  [SERVO] Open (90), holding 5 s"));
        } else {
          lockState = LOCK_CLOSED;
          onLockClosed();
        }
      }
    }
  } else if (lockState == LOCK_OPEN_HOLD) {
    if (now - holdStartTime >= HOLD_MS) {
      lockClose();
    }
  }
}

// ---------- EEPROM ----------
bool passwordStored() {
  return EEPROM.read(0) == EE_MAGIC;
}

void savePassword() {
  for (uint8_t i = 0; i < LIMIT; i++) EEPROM.update(1 + i, path[i]);
  EEPROM.update(0, EE_MAGIC);
}

void erasePassword() {
  EEPROM.update(0, 0xFF);
}

bool passwordMatches() {
  for (uint8_t i = 0; i < LIMIT; i++) {
    if (path[i] != (int8_t)EEPROM.read(1 + i)) return false;
  }
  return true;
}

// ---------- Joystick ----------
// Returns 'w'/'a'/'s'/'d' once per deflection, otherwise 0.
// The stick must return to center before it can trigger again.
char readJoystick() {
  static bool armed = true;
  int dx = analogRead(JOY_X) - JOY_CENTER;
  int dy = analogRead(JOY_Y) - JOY_CENTER;
  if (JOY_INVERT_X) dx = -dx;
  if (JOY_INVERT_Y) dy = -dy;

  int ax = abs(dx), ay = abs(dy);

  if (ax < JOY_RELEASE && ay < JOY_RELEASE) {
    armed = true;
    return 0;
  }
  if (armed && (ax > JOY_TRIGGER || ay > JOY_TRIGGER)) {
    armed = false;
    if (ax > ay) return (dx > 0) ? 'd' : 'a';
    return (dy > 0) ? 's' : 'w';
  }
  return 0;
}

// Joystick button press (debounced), true once per press
bool joyButtonPressed() {
  static bool lastRaw = HIGH, stable = HIGH;
  static uint32_t changed = 0;
  bool raw = digitalRead(JOY_SW);
  if (raw != lastRaw) {
    lastRaw = raw;
    changed = millis();
  }
  if (millis() - changed >= 40 && raw != stable) {
    stable = raw;
    if (stable == LOW) return true;
  }
  return false;
}

// ---------- FSM transitions ----------
void changeState(State next) {
  Serial.print(F("[FSM] "));
  Serial.print(stateName(state));
  Serial.print(F(" -> "));
  Serial.println(stateName(next));
  state = next;
  stateEntered = millis();
  onEnter(next);
}

void onEnter(State s) {
  switch (s) {
    case START:
      Serial.println(F("  All LEDs blinking"));
      lcdLine(0, F("Graphic lock"));
      lcdLine(1, F("Starting..."));
      break;
    case CHOOSE_START:
      attemptCount = 0;
      currentLED   = 0;
      pathLength   = 0;
      if (recordMode) {
        Serial.println(F("  No password set! Choose the start of the new pattern (w/a/s/d, e)"));
        lcdLine(0, F("Set new pattern"));
      } else {
        Serial.println(F("  Choose start: w/a/s/d = cursor, e = confirm, r = new password"));
        lcdLine(0, F("Enter pattern"));
      }
      lcdLine(1, F("Start: WASD, e"));
      break;
    case INPUT_PATH:
      if (recordMode) {
        Serial.print(F("  Recording: draw a path of "));
        Serial.print(LIMIT);
        Serial.println(F(" LEDs with the joystick, then press its button"));
        lcdLine(0, F("Draw new pattern"));
      } else {
        Serial.println(F("  Enter password: joystick or w/a/s/d = path, button or e = Enter"));
        lcdLine(0, F("Draw pattern"));
      }
      lcdProgress();
      break;
    case CHECK_PASS:
      Serial.println(F("  Comparing with the password from EEPROM..."));
      lcdLine(0, F("Checking..."));
      lcdLine(1, F(""));
      break;
    case UNLOCKED:
      Serial.println(F("  Password correct, green LED ON"));
      greenOn = true;
      beepOk();
      lcdLine(0, F("Access granted"));
      lcdLine(1, F("Door open"));
      lockOpen();
      break;
    case BLOCKED:
      Serial.println(F("  3 wrong attempts, locked by timer"));
      lastSecLeft = 255;
      beepsLeft = 0;
      tone(BUZZER_PIN, 300, 1000);                      // one long beep
      lcdLine(0, F("BLOCKED"));
      lcdLine(1, F("Wait 10 s"));
      break;
  }
}

// ---------- Helpers ----------
int8_t nextLED(int8_t from, char dir) {
  int8_t row = from / MATRIX_SIDE, col = from % MATRIX_SIDE;
  if (dir == 'w') row--;
  else if (dir == 's') row++;
  else if (dir == 'a') col--;
  else if (dir == 'd') col++;
  else return -1;
  if (row < 0 || row >= MATRIX_SIDE || col < 0 || col >= MATRIX_SIDE) return -1;
  return row * MATRIX_SIDE + col;
}

bool isDirection(char c) {
  return c == 'w' || c == 'a' || c == 's' || c == 'd';
}

bool inPath(int8_t led) {
  for (uint8_t i = 0; i < pathLength; i++) {
    if (path[i] == led) return true;
  }
  return false;
}

// ---------- 8x8 matrix on MAX7219 ----------
uint8_t frame[8];                    // frame[row]: bit 0x80 = column 0
uint8_t shown[8];                    // what the module currently displays

void buildFrame() {
  uint32_t now = millis();
  bool blinkSlow = (now / 250) % 2;
  bool blinkFast = (now / 100) % 2;

  for (uint8_t r = 0; r < 8; r++) frame[r] = 0;

  for (uint8_t i = 0; i < CELLS; i++) {
    bool on = false;
    switch (state) {
      case START:        on = blinkSlow; break;
      case CHOOSE_START: on = (i == currentLED) && blinkSlow; break;
      case INPUT_PATH:   on = inPath(i); break;
      case CHECK_PASS:   on = inPath(i); break;
      case UNLOCKED:     on = true; break;
      case BLOCKED:      on = blinkFast; break;
    }
    if (on) frame[i / MATRIX_SIDE] |= (uint8_t)(0x80 >> (i % MATRIX_SIDE));
  }
}

// Send only the rows that changed to the MAX7219
void showFrame() {
  for (uint8_t r = 0; r < 8; r++) {
    if (frame[r] != shown[r]) {
      shown[r] = frame[r];
      matrix.setRow(0, r, frame[r]);
    }
  }
}

// Matrix + red/green LEDs
void updateOutputs() {
  static uint32_t lastFrame = 0;
  uint32_t now = millis();

  if (now - lastFrame >= 20) {
    lastFrame = now;
    buildFrame();
    showFrame();
  }

  bool blinkFast = (now / 100) % 2;
  bool red = (now < redUntil) || (state == BLOCKED && blinkFast);
  digitalWrite(LED_RED,   red ? HIGH : LOW);
  digitalWrite(LED_GREEN, greenOn ? HIGH : LOW);
}

// ---------- Arduino ----------
void setup() {
  Serial.begin(9600);

  matrix.shutdown(0, false);         // wake the MAX7219 from power-down
  matrix.setIntensity(0, 8);         // brightness 0..15
  matrix.clearDisplay(0);

  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(JOY_SW, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();

  lockServo.attach(SERVO_PIN);
  lockServo.write(ANGLE_CLOSED);

  recordMode = !passwordStored();
  Serial.println(F("[FSM] Start"));
  changeState(START);
}

void loop() {
  char cmd = 0;                       // keyboard (Serial): choose start LED
  if (Serial.available()) cmd = Serial.read();

  char joy = readJoystick();          // joystick: draw the path
  bool btn = joyButtonPressed();      // joystick button: Enter

  uint32_t now = millis();
  lockUpdate();
  beeperUpdate();

  switch (state) {

    case START:
      if (now - stateEntered >= START_MS) {
        changeState(CHOOSE_START);
      }
      break;

    case CHOOSE_START:                                  // only w/a/s/d/e/r
      if (isDirection(cmd)) {
        int8_t n = nextLED(currentLED, cmd);
        if (n >= 0) {
          currentLED = n;
          beepMove();
          Serial.print(F("  Cursor on LED "));
          Serial.println(currentLED);
        }
      } else if (cmd == 'e') {
        path[0]    = currentLED;
        pathLength = 1;
        changeState(INPUT_PATH);
      } else if (cmd == 'r') {
        erasePassword();
        recordMode = true;
        Serial.println(F("  Password erased. Choose the start of the new pattern"));
        lcdLine(0, F("Set new pattern"));
      }
      break;

    case INPUT_PATH: {                                  // joystick or w/a/s/d, from the chosen LED
      char dir = joy ? joy : (isDirection(cmd) ? cmd : 0);
      bool enter = btn || cmd == 'e';
      if (dir && pathLength < LIMIT) {
        int8_t n = nextLED(path[pathLength - 1], dir);
        if (n >= 0) {
          path[pathLength++] = n;
          beepMove();
          Serial.print(F("  LED "));
          Serial.print(n);
          Serial.print(F(" (path length "));
          Serial.print(pathLength);
          Serial.println(F(")"));
          lcdProgress();
        } else {
          Serial.println(F("  Out of the matrix, move ignored"));
        }
      } else if (enter) {
        if (pathLength >= LIMIT) {
          if (recordMode) {
            savePassword();
            recordMode = false;
            beepOk();
            Serial.println(F("  Password saved to EEPROM"));
            changeState(CHOOSE_START);
          } else {
            changeState(CHECK_PASS);
          }
        } else {
          Serial.println(F("  Path is too short"));
        }
      }
      break;
    }

    case CHECK_PASS:
      if (passwordMatches()) {
        changeState(UNLOCKED);
      } else {
        attemptCount++;
        redUntil = now + 500;                           // red LED flashes
        Serial.print(F("  Wrong, attempt "));
        Serial.println(attemptCount);
        if (attemptCount >= MAX_ATTEMPTS) {
          changeState(BLOCKED);
        } else {
          if (attemptCount == 1) startBeeps(3, 600);    // 1st mistake: slow beeps
          else                   startBeeps(6, 150);    // 2nd mistake: fast beeps
          pathLength = 1;                               // keep the start LED
          changeState(INPUT_PATH);
          lcdLine(0, F("Wrong pattern"));
        }
      }
      break;

    case UNLOCKED:
      // servo opened, held 5 s, closed, green LED off
      if (lockState == LOCK_CLOSED) {
        changeState(CHOOSE_START);
      }
      break;

    case BLOCKED: {
      uint32_t passed = now - stateEntered;
      if (passed >= BLOCK_MS) {
        changeState(CHOOSE_START);
      } else {
        uint8_t left = (BLOCK_MS - passed) / 1000 + 1;
        if (left != lastSecLeft) {
          lastSecLeft = left;
          lcd.setCursor(0, 1);
          lcd.print(F("Wait "));
          lcd.print(left);
          lcd.print(F(" s     "));
        }
      }
      break;
    }
  }

  updateOutputs();
}
