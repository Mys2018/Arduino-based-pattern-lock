#include "Arduino.h"
void lockOpen(); void lockClose();
#include "graphic_lock_wokwi.ino"
void tick(uint32_t n){for(uint32_t i=0;i<n;i++){++sim_ms;loop();}}
void command(char c){Serial.input.push_back(c);tick(1);}
void commands(const std::string& s){for(char c:s)command(c);}
void boot(bool seeded=true){analog_pins[A0]=analog_pins[A1]=512;if(seeded){EEPROM.update(0,0xA5);int p[]={0,1,9,10};for(int i=0;i<4;i++)EEPROM.update(i+1,p[i]);}setup();tick(1600);}
void pathP(){commands("edsde");tick(2);}
void wrong(){commands("esdse");tick(2);}
void nextWrong(){commands("sdse");tick(2);}
int main(int argc,char**argv){
 if(argc!=2)return 2;std::string test=argv[1];bool ok=false;std::string observation;
 if(test=="startup"){boot();ok=state==CHOOSE_START&&currentAngle==0&&attemptCount==0;observation="state="+std::string(stateName(state))+", angle="+std::to_string(currentAngle);}
 else if(test=="valid"){boot();pathP();tick(1400);ok=state==UNLOCKED&&currentAngle==90&&greenOn;observation="angle="+std::to_string(currentAngle)+", state="+stateName(state);}
 else if(test=="servo_cycle"){boot();pathP();tick(1350);uint32_t hold=holdStartTime;tick(5000);uint32_t closeStart=sim_ms;tick(1400);ok=state==CHOOSE_START&&currentAngle==0&&!greenOn;observation="hold_start="+std::to_string(hold)+", observed_close_phase="+std::to_string(closeStart)+", end_angle="+std::to_string(currentAngle);}
 else if(test=="wrong_counts"){boot();wrong();int first=attemptCount;nextWrong();ok=first==1&&attemptCount==2&&state==INPUT_PATH&&currentAngle==0;observation="first="+std::to_string(first)+", second="+std::to_string(attemptCount);}
 else if(test=="three_wrong"){boot();wrong();nextWrong();nextWrong();ok=state==BLOCKED&&attemptCount==3&&currentAngle==0;observation="state="+std::string(stateName(state))+", attempts="+std::to_string(attemptCount);}
 else if(test=="block_duration"){boot();wrong();nextWrong();nextWrong();uint32_t start=stateEntered;while(state==BLOCKED&&sim_ms-start<31000)tick(1);auto duration=sim_ms-start;ok=duration>=30000;observation="lockout_duration_ms="+std::to_string(duration)+"; requirement=30000";}
 else if(test=="blocked_input"){boot();wrong();nextWrong();nextWrong();commands("redsde");tick(1000);ok=state==BLOCKED&&passwordStored()&&currentAngle==0;observation="state="+std::string(stateName(state))+", stored="+std::to_string(passwordStored());}
 else if(test=="post_block"){boot();wrong();nextWrong();nextWrong();tick(BLOCK_MS+2);wrong();ok=state==INPUT_PATH&&attemptCount==1;observation="attempts_after_timeout_and_one_wrong="+std::to_string(attemptCount);}
 else if(test=="short"){boot();commands("ee");ok=state==INPUT_PATH&&pathLength==1&&attemptCount==0;observation="length="+std::to_string(pathLength)+", attempts="+std::to_string(attemptCount);}
 else if(test=="length_limit"){boot();commands("edsdss");ok=pathLength==4;observation="pathLength="+std::to_string(pathLength);}
 else if(test=="bounds"){boot();bool top=nextLED(0,'w')==-1,bottom=nextLED(56,'s')==-1,left=nextLED(0,'a')==-1,right=nextLED(7,'d')==-1;commands("ewa");ok=top&&bottom&&left&&right&&pathLength==1;observation="4 direction boundaries rejected; pathLength="+std::to_string(pathLength);}
 else if(test=="joy_hold"){boot();command('e');analog_pins[A0]=0;tick(2000);ok=pathLength==2;observation="one held deflection: pathLength="+std::to_string(pathLength);}
 else if(test=="joy_rearm"){boot();command('e');analog_pins[A0]=0;tick(20);analog_pins[A0]=512;tick(20);analog_pins[A0]=0;tick(20);ok=pathLength==3;observation="two deflections with release: pathLength="+std::to_string(pathLength);}
 else if(test=="joy_shifted_center"){analog_pins[A0]=850;analog_pins[A1]=512;EEPROM.update(0,0xA5);setup();tick(1600);analog_pins[A0]=512;tick(50);command('e');analog_pins[A0]=850;tick(50);ok=pathLength==1;observation="stick resting at calibrated-needed center 850: pathLength="+std::to_string(pathLength);}
 else if(test=="button"){boot();commands("edsd");digital_pins[12]=LOW;tick(150);ok=state==UNLOCKED;observation="held SEL once: state="+std::string(stateName(state));}
 else if(test=="first_record"){boot(false);commands("edsde");ok=passwordStored()&&!recordMode&&state==CHOOSE_START&&EEPROM.read(1)==0&&EEPROM.read(4)==10;observation="first new pattern stored="+std::to_string(passwordStored());}
 else if(test=="unauth_reset"){boot();command('r');bool erased=!passwordStored();commands("esdse");commands("esdse");tick(1400);ok=!erased&&currentAngle==0;observation="unauthenticated_r_erases="+std::to_string(erased)+", attacker_new_key_angle="+std::to_string(currentAngle);}
 else if(test=="counter_single"){boot();wrong();tick(5000);ok=attemptCount==1;observation="after 5 seconds idle: attempts="+std::to_string(attemptCount);}
 else if(test=="eeprom_restart"){boot();uint8_t before=EEPROM.read(4);setup();tick(1600);ok=!recordMode&&passwordStored()&&before==EEPROM.read(4);observation="EEPROM retained on setup restart; recordMode="+std::to_string(recordMode);}

 else if(test=="neutral"){boot();commands("se");tick(5000);ok=pathLength==1;observation="neutral 5s: pathLength="+std::to_string(pathLength);}
 else if(test=="four_directions"){boot();bool all=true;int expected[]={1,17,8,10};int xs[]={512,512,1023,0};int ys[]={1023,0,512,512};for(int i=0;i<4;i++){state=INPUT_PATH;path[0]=9;pathLength=1;analog_pins[A0]=analog_pins[A1]=512;tick(20);analog_pins[A0]=xs[i];analog_pins[A1]=ys[i];tick(100);all=all&&pathLength==2&&path[1]==expected[i];}ok=all;observation="up/down/left/right from cell 9: expected 1/17/8/10";}
 else if(test=="all_path_boundaries"){boot();bool all=true;int origins[]={1,57,8,15};std::string dirs="wsad";for(int i=0;i<4;i++){state=INPUT_PATH;path[0]=origins[i];pathLength=1;int prev=attemptCount;command(dirs[i]);all=all&&pathLength==1&&path[0]==origins[i]&&attemptCount==prev;}ok=all;observation="all 4 INPUT_PATH boundary attempts ignored, length/counter unchanged";}
 else if(test=="choose_joystick"){boot();analog_pins[A0]=0;tick(300);analog_pins[A0]=512;tick(100);digital_pins[12]=LOW;tick(100);ok=currentLED==1&&state==INPUT_PATH;observation="joystick-only start: currentLED="+std::to_string(currentLED)+", state="+stateName(state);}
 else if(test=="button_bounce"){boot();command('e');for(int i=0;i<8;i++){digital_pins[12]=(i%2)?HIGH:LOW;tick(5);}bool noEarly=Serial.log.find("Path is too short")==std::string::npos;digital_pins[12]=LOW;tick(100);auto first=Serial.log;digital_pins[12]=HIGH;tick(100);digital_pins[12]=LOW;tick(100);auto count=[](const std::string& s){int n=0;size_t p=0;while((p=s.find("Path is too short",p))!=std::string::npos){n++;p++;}return n;};ok=noEarly&&count(first)==1&&count(Serial.log)==2;observation="no event during bouncing; 1 event for held press; 2 events after second press";}
 else if(test=="success_resets_errors"){boot();wrong();nextWrong();commands("dsde");tick(8000);wrong();ok=attemptCount==1&&state==INPUT_PATH;observation="two errors, success, close, wrong: attempts="+std::to_string(attemptCount);}
 else if(test=="repeat_cycle"){boot();pathP();tick(8000);wrong();commands("dsde");tick(1400);bool second=state==UNLOCKED&&currentAngle==90;tick(6500);ok=second&&state==CHOOSE_START&&currentAngle==0;observation="P-close-Q-P-close completed";}
 else return 3;
 std::cout<<"TEST="<<test<<"\nRESULT="<<(ok?"PASS":"FAIL")<<"\nOBSERVATION="<<observation<<"\n--- SERIAL ---\n"<<Serial.log;
 return ok?0:1;
}
