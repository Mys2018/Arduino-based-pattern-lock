#pragma once
#include "Arduino.h"
struct EEPROMMock{uint8_t data[4096];EEPROMMock(){for(auto &x:data)x=255;}uint8_t read(int i){return data[i];}void update(int i,uint8_t v){data[i]=v;}};inline EEPROMMock EEPROM;
