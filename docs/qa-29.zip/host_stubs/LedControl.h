#pragma once
#include "Arduino.h"
struct LedControl{uint8_t rows[8]={};LedControl(int,int,int,int){}void shutdown(int,bool){}void setIntensity(int,int){}void clearDisplay(int){for(auto &x:rows)x=0;}void setRow(int,int r,uint8_t v){rows[r]=v;}};
