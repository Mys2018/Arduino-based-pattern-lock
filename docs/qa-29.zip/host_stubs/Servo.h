#pragma once
#include "Arduino.h"
struct Servo{int angle=0;void attach(int){} void write(int a){angle=a;}};
