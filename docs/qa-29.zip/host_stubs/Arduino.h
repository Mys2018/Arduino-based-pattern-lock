#pragma once
#include <cstdint>
#include <cstdlib>
#include <deque>
#include <string>
#include <sstream>
#include <iostream>
using std::uint8_t; using std::int8_t; using std::uint16_t; using std::uint32_t;
struct __FlashStringHelper {};
#define F(x) reinterpret_cast<const __FlashStringHelper*>(x)
constexpr int HIGH=1,LOW=0,OUTPUT=1,INPUT_PULLUP=2,A0=54,A1=55,LED_BUILTIN=13;
inline uint32_t sim_ms=0;
inline int analog_pins[100]={};
inline int digital_pins[100]={};
inline uint32_t millis(){return sim_ms;}
inline int analogRead(int p){return analog_pins[p];}
inline int digitalRead(int p){return digital_pins[p];}
inline void digitalWrite(int p,int v){digital_pins[p]=v;}
inline void pinMode(int p,int m){if(m==INPUT_PULLUP)digital_pins[p]=HIGH;}
inline void tone(int,int,int){}
inline char pgm_read_byte(const char* p){return *p;}
struct SerialMock {
 std::deque<char> input; std::string log;
 void begin(int){}
 int available(){return int(input.size());}
 char read(){char c=input.front();input.pop_front();return c;}
 template<class T> void print(T v){std::ostringstream o;o<<v; log+=o.str();}
 void print(uint8_t v){print(int(v));}
 void print(int8_t v){print(int(v));}
 void print(const __FlashStringHelper* p){log+=reinterpret_cast<const char*>(p);}
 template<class T> void println(T v){print(v);log+='\n';}
 void println(){log+='\n';}
};
inline SerialMock Serial;
