/*
  Графический замок на Arduino
  Задача #8: Модуль управления сервоприводом SG90 в симуляторе

  - Сервопривод SG90 подключён к D9
  - lockOpen()  - плавный поворот на 90°, затем удержание
  - lockClose() - возврат на 0°
  - Всё работает через millis(), delay() не используется,
    поэтому loop() не блокируется
  - Статус выводится в Serial Monitor
*/

#include <Servo.h>

// ---------- Настройки ----------
const uint8_t  SERVO_PIN        = 9;
const uint8_t  ANGLE_CLOSED     = 0;
const uint8_t  ANGLE_OPEN       = 90;
const uint16_t STEP_INTERVAL_MS = 15;     // 1° за 15 мс => 90° примерно за 1.35 с
const uint32_t HOLD_MS          = 5000;   // шаг 18 блок-схемы: ждём 5 сек в открытом положении
const bool     AUTO_CLOSE       = true;   // закрывать автоматически после удержания

// ---------- Состояние замка ----------
Servo lockServo;

enum LockState { CLOSED, OPENING, OPEN_HOLD, CLOSING };
LockState lockState = CLOSED;

int      currentAngle  = ANGLE_CLOSED;
int      targetAngle   = ANGLE_CLOSED;
uint32_t lastStepTime  = 0;
uint32_t holdStartTime = 0;

// ---------- Точки интеграции с блок-схемой ----------

// Шаг 12 (ДА): пароль совпал с EEPROM -> вызвать эту функцию
void onPasswordCorrect() {
  lockOpen();
}

// Вызывается, когда замок снова закрыт (после шага 18).
// Здесь: реле ВЫКЛ, attemptCount = 0, возврат к шагу 3 (выбор старта)
void onLockClosed() {
  // digitalWrite(RELAY_PIN, LOW);
  // attemptCount = 0;
  // mode = START_SELECT;
}

// ---------- Функции замка ----------

// Плавно повернуть на 90° и удерживать HOLD_MS
void lockOpen() {
  if (lockState == OPENING || lockState == OPEN_HOLD) return;
  targetAngle = ANGLE_OPEN;
  lockState = OPENING;
  Serial.println(F("[LOCK] Открывается..."));
}

// Вернуть сервопривод на 0°
void lockClose() {
  if (lockState == CLOSING || lockState == CLOSED) return;
  targetAngle = ANGLE_CLOSED;
  lockState = CLOSING;
  Serial.println(F("[LOCK] Закрывается..."));
}

// Вызывать в каждом loop(): делает шаги сервы и отсчитывает удержание
void lockUpdate() {
  uint32_t now = millis();

  if (lockState == OPENING || lockState == CLOSING) {
    if (now - lastStepTime >= STEP_INTERVAL_MS) {
      lastStepTime = now;
      currentAngle += (targetAngle > currentAngle) ? 1 : -1;
      lockServo.write(currentAngle);

      if (currentAngle == targetAngle) {
        if (lockState == OPENING) {
          lockState = OPEN_HOLD;
          holdStartTime = now;
          Serial.println(F("[LOCK] ОТКРЫТ (90 градусов), удержание..."));
        } else {
          lockState = CLOSED;
          Serial.println(F("[LOCK] ЗАКРЫТ (0 градусов)"));
          onLockClosed();
        }
      }
    }
  } else if (lockState == OPEN_HOLD && AUTO_CLOSE) {
    if (now - holdStartTime >= HOLD_MS) {
      lockClose();
    }
  }
}

// ---------- Arduino ----------
uint32_t lastBlink = 0;

void setup() {
  Serial.begin(9600);
  pinMode(LED_BUILTIN, OUTPUT);

  lockServo.attach(SERVO_PIN);
  lockServo.write(ANGLE_CLOSED);

  Serial.println(F("[LOCK] Готов. Команды: 'o' - открыть, 'c' - закрыть"));
}

void loop() {
  lockUpdate();   // не блокирует выполнение

  // Команды из Serial Monitor
  if (Serial.available()) {
    char cmd = Serial.read();
    if (cmd == 'o') onPasswordCorrect();   // имитация шага 12 (пароль верный)
    else if (cmd == 'c') lockClose();
  }

  // Доказательство неблокирующей работы: светодиод мигает,
  // даже пока сервопривод двигается или удерживается
  if (millis() - lastBlink >= 250) {
    lastBlink = millis();
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
  }

  // Здесь позже будет остальная логика замка (ввод ключа, проверка и т.д.)
}
