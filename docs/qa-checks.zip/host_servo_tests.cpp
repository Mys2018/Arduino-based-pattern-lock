#include "Arduino.h"
void lockOpen(); void lockClose();
#include "servo_module.ino"
void tick(uint32_t n){for(uint32_t i=0;i<n;i++){++sim_ms;loop();}}
void cmd(char c){Serial.input.push_back(c);tick(1);}
int main(int argc,char**argv){
 if(argc!=2) return 2;
 setup();
 std::string test=argv[1]; bool ok=false;
 if(test=="cycle"){cmd('o');tick(8000);ok=lockState==CLOSED&&currentAngle==0;}
 else if(test=="quick_close"){cmd('o');cmd('c');tick(100);ok=lockState==CLOSED&&currentAngle==0;}
 else return 3;
 std::cout<<"TEST="<<test<<"\nRESULT="<<(ok?"PASS":"FAIL")<<"\nOBSERVATION=currentAngle="<<currentAngle<<", lockState="<<lockState<<"\n--- SERIAL ---\n"<<Serial.log;
 return ok?0:1;
}
